# HOS Calculator — 70-Hour / 8-Day

An installable Progressive Web App (PWA) that helps US truck drivers track their
available driving hours under the Federal **70-hour / 8-day** Hours of Service
(HOS) rule. Installs to the home screen on iPhone, iPad, and Android, runs
full-screen with its own icon, and works completely offline. No app store, no
account, no fees.

> **Not a substitute for an ELD or your official logbook.** This is a planning
> and double-check tool. Always follow your company policy and the FMCSA rules
> of record. See the disclaimer at the bottom of this file.

---

## What it does

- **70-hour / 8-day rolling calculation** — enter the hours you drove on each of
  the previous 7 days plus today, and it shows how many hours you have left.
- **Driver name** — labels the session and the exported summary.
- **Operating timezone** — set once at first launch; the 8-day log rolls over
  automatically at midnight in that zone (this is the "hours gained back" each
  night as the oldest day drops off the 8-day window).
- **Today's hours** — enter total hours worked today.
- **Today's mileage** — enter distance driven today, in miles or kilometers.
- **Reset** — one tap clears all hours and mileage to start a fresh cycle.
- **Import / Export Data** — save a backup file of your current numbers and
  reload it later or on another device.
- **Accessibility built in** — minimum 12 pt text, a text-size slider up to
  **300%**, and a color-blind-safe palette.
- **Offline-first** — after the first visit it runs with no signal, which is the
  point for drivers in dead zones.

---

## Files in this folder

```
index.html          The complete app (self-contained, no external calls)
manifest.json       PWA manifest — name, icons, colors, display mode
sw.js               Service worker — offline caching
icon-192.png        App icon (192×192)
icon-512.png        App icon (512×512)
apple-touch-icon.png  iOS home-screen icon (180×180)
_headers            Security/cache headers for Netlify
netlify.toml        Netlify hosting config
README.md           This file
USER-GUIDE.md       Step-by-step "how to use it" for drivers
```

---

## Getting it onto phones (two steps)

A PWA must be served from a web link (`https://…`) for the install and offline
features to work. It will **not** install if opened as a local file. The free
options below take about five minutes.

### Step 1 — Put it online (pick one)

**Option A — Netlify Drop (easiest, no account needed to start)**
1. Go to <https://app.netlify.com/drop>.
2. Drag this entire folder onto the page.
3. Netlify gives you a link like `https://random-name.netlify.app`. That's your app.
4. (Optional) Make a free account to rename it to something like
   `safeway-hos.netlify.app`.

**Option B — GitHub Pages (free, good if you already use GitHub)**
1. Create a new repository and upload every file in this folder to it.
2. Settings → Pages → Source: deploy from `main` branch, root folder.
3. Your app appears at `https://yourname.github.io/repo-name/`.

### Step 2 — Install on the phone

**iPhone / iPad (must use Safari):**
1. Open the link in **Safari**.
2. Tap the **Share** button (square with an up arrow).
3. Scroll down and tap **Add to Home Screen** → **Add**.
4. The HOS icon appears on the home screen. Open it from there for full-screen mode.

**Android (Chrome):**
1. Open the link in **Chrome**.
2. Tap the **⋮** menu (top right).
3. Tap **Install app** (or **Add to Home screen**) → **Install**.
4. The icon lands in your app drawer like any other app.

Once installed, drivers just tap the icon — no link to remember.

---

## Updating the app later

Edit `index.html`, then re-upload the folder to the same Netlify/GitHub location.
The service worker version is bumped per release so installed copies pick up the
new version next time they open with a signal. If a device seems stuck on an old
version, close the app fully and reopen it once with data on.

---

## Technical notes

- 100% client-side. No backend, no analytics, no network calls — `connect-src`
  is restricted to same-origin only.
- Numbers are kept on the device. The Export feature is the only way data leaves
  the device, and only when the driver chooses to.
- Content Security Policy is locked to same-origin scripts/styles plus inline
  (required by the single-file design).
- Tested on Safari (iOS 14+), Chrome (Android), and Chrome/Safari/Edge/Firefox
  on desktop.

---

## Disclaimer

This tool is provided for convenience and planning only. It does **not** replace
a compliant Electronic Logging Device (ELD), your carrier's policies, or the
official FMCSA Hours of Service regulations. The driver and carrier remain solely
responsible for compliance. Verify all figures against your system of record
before relying on them.

## Version

Current version: **3.0.0**. The version is defined once in `index.html` (the
`VERSION` constant) and is shown automatically in the app footer, so bumping that
single value updates the displayed version on every release. The service-worker
cache name (`hos-calc-vN` in `sw.js`) should be bumped alongside it so installed
copies pick up the update.

## License

Proprietary — Robert W Donze (robert.donze@gmail.com). All rights reserved.

Copyright © 2025 Robert W Donze. No part of this application may be copied,
distributed, or modified without the express written permission of the copyright
holder.

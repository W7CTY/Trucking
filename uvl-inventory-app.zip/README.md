# UVL Inventory — Safeway U199

An installable Progressive Web App (PWA) for creating United Van Lines
**Descriptive Inventory** sheets in the field. Installs to the home screen on
iPhone, iPad, and Android, runs full-screen with its own icon, and works offline.
No app store required.

---

## What it does

- **Multi-job management** — keep several inventory jobs going and switch between them.
- **Descriptive Inventory form** — mirrors the standard UVL form fields.
- **Barcode scanner** — tap the camera button on any Tag No field to scan a label
  with the phone camera (Code 128/39, QR, EAN, UPC). Manual entry is always available
  as a fallback.
- **Condition / exception codes** — searchable picker for the standard location and
  exception codes.
- **Digital signatures** — capture driver and customer signatures by finger or stylus,
  at both origin and destination.
- **Auto date/time** — origin date and time fill in automatically when you reach the
  Signatures tab (never overwrites values you've already typed).
- **PDF generation** — print-ready 8.5×11 output. The default save name is built for
  you, e.g. `Inventory_Order_12345_John_Smith_20260530`.
- **Email a copy** — automatically (with PDF attached) via a free EmailJS account, or
  by handing off to the phone's own email app.
- **Offline capable** — works without internet after the first visit.

---

## Files in this folder

```
index.html          The complete app (with built-in Instructions screen)
manifest.json       PWA manifest — name, icons, colors, display mode
sw.js               Service worker — offline caching
icon-192.png        App icon (192×192)
icon-512.png        App icon (512×512)
apple-touch-icon.png  iOS home-screen icon (180×180)
_headers            Security/cache headers for Netlify
netlify.toml        Netlify hosting config
open-in-safari.html iPad helper that re-opens the app in Safari from the Files app
README.md           This file
USER-GUIDE.md       Step-by-step "how to use it" for crews
```

---

## Getting it onto phones (two steps)

A PWA must be served from a web link (`https://…`) for install, camera, and offline
to work. It will **not** install (and the camera scanner may be blocked) if opened as
a local file. The free options below take about five minutes.

### Step 1 — Put it online (pick one)

**Option A — Netlify Drop (easiest)**
1. Go to <https://app.netlify.com/drop>.
2. Drag this entire folder onto the page.
3. You'll get a link like `https://random-name.netlify.app`. That's your app.
4. (Optional) Make a free account to rename it to e.g. `safeway-inventory.netlify.app`.

**Option B — GitHub Pages**
1. Create a repository and upload every file in this folder.
2. Settings → Pages → deploy from `main`, root folder.
3. Your app appears at `https://yourname.github.io/repo-name/`.

> Hosting over HTTPS is also what lets the **camera barcode scanner** work — browsers
> only allow camera access on secure (`https`) pages.

### Step 2 — Install on the phone

**iPhone / iPad (must use Safari):**
1. Open the link in **Safari**.
2. Tap **Share** → **Add to Home Screen** → **Add**.

**Android (Chrome):**
1. Open the link in **Chrome**.
2. Tap **⋮** → **Install app** (or **Add to Home screen**) → **Install**.

---

## Email setup (optional)

The app can email a copy of the inventory to the customer two ways:

- **EmailJS (automatic, PDF attached)** — a free [EmailJS](https://www.emailjs.com)
  account (about 200 emails/month free). You enter the credentials once in the app's
  **⚙ Settings** screen; nothing is hard-coded. The in-app **EmailJS Guide** walks
  through every step.
- **Device email app (manual)** — no setup. Opens the phone's email app with the
  address and subject filled in; you attach the PDF yourself.

---

## Updating the app later

Edit `index.html`, then re-upload the folder to the same Netlify/GitHub location.
The service worker cache version is bumped per release so installed copies refresh
on next open with a signal.

---

## Security

- Content Security Policy restricting script sources; Subresource Integrity on the
  EmailJS CDN script.
- All user input sanitized before it touches the page; email fields validated and
  stripped of newlines (prevents header injection).
- No `eval`, no `document.write`. Async actions wrapped in error handling, with
  double-submit protection on send.
- All data stays on the device. Nothing is sent anywhere except EmailJS, and only
  when you configure it and choose to send.

---

## Version

Current version: **3.0.0**. The version is defined once in `index.html` (the
`VERSION` constant) and shown automatically in the app footer, so bumping that
single value updates the displayed version on every release. Bump the
service-worker cache name (`uvl-vN` in `sw.js`) alongside it so installed copies
refresh.

## License

Proprietary — Robert W Donze (robert.donze@gmail.com). All rights reserved.

Copyright © 2025 Robert W Donze. No part of this application may be copied,
distributed, or modified without the express written permission of the copyright
holder.

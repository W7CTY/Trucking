# UVL Inventory — User Guide

A plain-English walkthrough for crews. The app also has a built-in **📖 Instructions**
button that covers the same ground on the device itself. To get the app onto a phone,
see the "Getting it onto phones" section of `README.md`.

---

## The home screen — Inventory Jobs

When you open the app you see your list of **Inventory Jobs**.

- Tap **+ New Inventory Sheet** to start a job.
- Tap any existing job to reopen and keep editing it.
- Each job is saved on the device automatically as you work.

A new inventory has three tabs across the top: **Job Info**, **Items**, and
**Signatures**. You can move between them at any time.

---

## 1. Job Info tab

Fill in the order/customer details (order number, customer name, addresses, etc.).
Tap **Save & Continue →** to move on to Items. Anything you enter here feeds the
PDF and the auto-generated file name later.

---

## 2. Items tab

This is where you build the inventory line by line.

- Tap **+ Add Item** to create a row.
- **Tag No** — type it, or tap the **📷 camera button** beside the field to scan the
  barcode on the tag. The scanner opens full-screen, prefers the rear camera, and
  fills the field the instant it reads a code. If the camera can't be used, tap
  **Or type tag number manually…**.
- **Condition / exception codes** — tap into the codes field and use **Select
  Condition Code**. Search by code or description (e.g. type "scratched") and tap to
  add. Use the **Codes** reference button any time you need to look one up.
- Repeat for every item. Rows are saved as you go.

> Tip: scanning is fastest when the tag is well lit and the camera is 4–8 inches away.

---

## 3. Signatures tab

- When you open this tab, the **origin date and time fill in automatically** with the
  device's current date/time — unless you already typed something, in which case your
  values are kept. Destination date/time stay blank until delivery.
- Capture each signature by signing with a finger or stylus in the box: **driver** and
  **customer**, at **origin** and (later, at delivery) **destination**.
- Tap **Clear** under a box to redo a signature.

---

## Saving as PDF

Tap **📄 Save / Print PDF**. The app builds a clean 8.5×11 print-ready document and
hands it to your phone's print/share sheet, where you can **Save as PDF**, AirDrop, or
print it.

The default file name is built automatically, for example:
`Inventory_Order_12345_John_Smith_20260530`
(If there's no order number it falls back to `Inventory_[date]`.)

---

## Emailing a copy to the customer

Tap the email/send option and enter the **Customer email address**.

- If you've set up **EmailJS** in **⚙ Settings**, the app sends the email with the PDF
  attached automatically.
- If not, tap **Skip — Use Device Email App** to open your phone's email with the
  address and subject pre-filled; attach the PDF yourself and send.

To set up automatic email once, open **⚙ Settings → 📖 EmailJS Guide** and follow the
five steps (create a free account, connect your email, create a template, copy your
public key, paste it in). After that, sending is one tap.

---

## Saving and coming back later (In-App Save)

Every job is stored on the device automatically. Close the app and your jobs are still
in the **Inventory Jobs** list when you return — even with no signal. Use **💾 Save**
to force-save at any point.

---

## Working offline

After the first time you open the installed app with a signal, it runs with **no
internet**. Scanning, signatures, PDF creation, and saving all work offline. Emailing
needs a connection only at the moment you actually send.

---

## Troubleshooting

- **Camera won't open / scanner is blank** — make sure you opened the app from its
  installed icon or an `https://` link (cameras are blocked on plain file links), and
  that you allowed camera permission when asked. Use manual tag entry as a fallback.
- **Opened inside Facebook/Instagram and things look off** — those in-app browsers are
  limited. Use **Open in Browser** (or on iPad, the included `open-in-safari.html`
  helper) to launch it in Safari/Chrome.
- **Email didn't send automatically** — check your EmailJS credentials in Settings, or
  just use the device email app option.

---

## A typical job, start to finish

1. **+ New Inventory Sheet** → fill **Job Info** → **Save & Continue**.
2. **Items**: add each item, scanning tags and adding condition codes.
3. **Signatures**: confirm the auto date/time, capture driver + customer signatures.
4. **Save / Print PDF**, and email the customer a copy.
5. At delivery, reopen the job, capture destination signatures, and re-save/send.
